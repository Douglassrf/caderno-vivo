# Caderno Vivo

Prototipo local do Caderno Vivo com Fases 1 a 9 concluidas e auditadas, agora com internacionalizacao comercial.

Abra `index.html` no navegador para testar. Os dados ficam salvos no armazenamento local do navegador.

## Estado atual

- Fase 1: caderno de composicao.
- Fase 2: memoria e audio.
- Fase 3: Proteger e Receber.
- Fase 4: Mentor Criativo.
- Fase 4.1: Adaptacao Internacional da musica, preservando sentido, emocao, metrica e rima.
- Fase 5: Repertorio e Producao.
- Fase 6: Lancamento e Carreira.
- Fase 7: Videoclipe Cinematografico.
- Fase 7.1: exportacao, imagem, takes e montagem.
- Fase 7.2: Videoclipe Internacional.
- Fase 8: renderizacao e exportacao final do videoclipe.
- Fase 9: exportacao MP4 profissional com FFmpeg.
- Monetizacao: Plano Plus para adaptacao internacional e Plano Prime para videoclipe internacional.
- Politica comercial/juridica: compositor profissional mantem 100%; criador assistido aceita 50/50 para profissionalizar, distribuir ou monetizar.
- Gatilhos inteligentes: ofertas aparecem como destravamentos, sem interromper a composicao.

Ultima validacao registrada nesta entrega: politica comercial/juridica aprovada com 6 verificacoes funcionais, 0 falhas e console do navegador sem erros.
