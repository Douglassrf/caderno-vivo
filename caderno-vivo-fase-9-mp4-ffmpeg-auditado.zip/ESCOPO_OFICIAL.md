﻿# Caderno Vivo - Escopo Oficial

Este projeto e a fonte oficial atual do Caderno Vivo.

Fase 1: caderno de composicao, obras, letra, metadados, blocos, versoes e cofre de frases.
Fase 2: audio/catalogacao local, comparador, sessoes guiadas e Nao deixa morrer.
Fase 3: Proteger e Receber, autores, percentuais, checklists, Dossie Criativo e hash local.
Fase 4: Mentor Criativo para completar trechos, criar letra guiada, melhorar estrofes/refroes e analisar metrica simples.
Fase 5: Repertorio e Producao, com etapa da obra, prioridade, prazo alvo, proxima acao, checklist de pre-producao e inclusao desses dados no dossie.
Fase 6: Lancamento e Carreira, com status de lancamento, data, distribuidora, ISRC/UPC, link principal, campanha, checklist de lancamento e inclusao desses dados no dossie.
Fase 7: Videoclipe Cinematografico, com conceito visual, formato, estilo, paleta, personagem, locacao, roteiro por cenas, prompts para geradores de video com IA, storyboard visual, prompts de imagem/capa, controle de takes, links de video, notas de montagem, exportacao de roteiro/prompts, checklist de direitos/preparo e inclusao desses dados no dossie.
Fase 8: Videoclipe Pronto Para Publicar, com presets para TikTok, Reels, Shorts, YouTube, Instagram Feed, Instagram Stories, Spotify Canvas e Arquivo Mestre, renderizacao local, preview, download do video, pacote de publicacao e inclusao desses dados no dossie.
Fase 9: Exportacao MP4 Profissional com FFmpeg, com conversao do video renderizado para `.mp4`, download de MP4, status de FFmpeg, pacote de publicacao com MP4 e inclusao desses dados no dossie.
Regra: qualquer mudanca deve respeitar este escopo e preservar as fases aprovadas.
