﻿# Regra Mestra Interna

Arquivo privado da equipe. Nao expor em interface, marketing ou documentacao publica ao usuario final.

Diretriz: cada fase deve entregar a melhor qualidade possivel ao artista, com foco em elevar a chance de uma obra forte, memoravel, bem estruturada e profissional.
